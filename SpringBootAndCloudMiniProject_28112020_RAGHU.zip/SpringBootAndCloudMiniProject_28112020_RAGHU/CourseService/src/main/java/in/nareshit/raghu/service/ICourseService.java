package in.nareshit.raghu.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.nareshit.raghu.model.Course;

public interface ICourseService {

	public Integer saveCourse(Course c);
	public Course getOneCourse(Integer id);
	public Page<Course> getAllCourses(Pageable p);
}
