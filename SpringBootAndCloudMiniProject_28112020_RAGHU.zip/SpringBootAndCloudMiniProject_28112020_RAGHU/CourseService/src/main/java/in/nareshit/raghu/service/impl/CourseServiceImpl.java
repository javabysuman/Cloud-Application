package in.nareshit.raghu.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.exception.CourseNotFoundException;
import in.nareshit.raghu.model.Course;
import in.nareshit.raghu.repo.CourseRepository;
import in.nareshit.raghu.service.ICourseService;
import in.nareshit.raghu.util.CourseUtil;

@Service
public class CourseServiceImpl implements ICourseService {
	@Autowired
	private CourseRepository repo;
	@Autowired
	private CourseUtil util;
	
	@Override
	public Integer saveCourse(Course c) {
		util.calcaulateDynamics(c);
		c = repo.save(c);
		return c.getCid();
	}

	@Override
	public Course getOneCourse(Integer id) {
		return repo.findById(id).orElseThrow(
				()->new CourseNotFoundException("Course Not exist"));
	}

	@Override
	public Page<Course> getAllCourses(Pageable p) {
		Page<Course> list = repo.findAll(p);
		return list;
	}

}
