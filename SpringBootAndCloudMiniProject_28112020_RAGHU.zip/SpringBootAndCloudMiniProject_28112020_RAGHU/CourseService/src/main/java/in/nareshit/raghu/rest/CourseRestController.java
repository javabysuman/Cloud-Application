package in.nareshit.raghu.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.exception.CourseNotFoundException;
import in.nareshit.raghu.model.Course;
import in.nareshit.raghu.service.ICourseService;

@RestController
@RefreshScope
@RequestMapping("/course")
public class CourseRestController {
	
	private static final Logger LOG = LoggerFactory.getLogger(CourseRestController.class);
	
	@Autowired
	private ICourseService service;	
	
	//1. save Course
	//@PostMapping("/save")
	@PostMapping
	public ResponseEntity<String> saveCourse(@RequestBody Course c) {
		LOG.info("ENTERED INTO SAVE COURSE METHOD");
		
		ResponseEntity<String> resp = null;
		try {
			Integer id = service.saveCourse(c);
			LOG.info("COURSE SAVED {}",id);
			//resp = ResponseEntity.ok("Course '"+id+"' Created");
			resp = new ResponseEntity<String>(
					"Course '"+id+"' Created",
					HttpStatus.CREATED);
		} catch (Exception e) {
			LOG.error("UNABLE TO SAVE COURSE {}", e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to save Course",
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		LOG.info("RETURNING BACK FROM SAVE COURSE METHOD ");
		return resp;
	}
	
	//2. Fetch Course by Id
	//@GetMapping("/one/{id}")
	@GetMapping("/{id}")
	public ResponseEntity<?> getCourseById(
			@PathVariable Integer id) 
	{
		LOG.info("ENTERED INTO GET ONE COURSE METHOD");
		ResponseEntity<?> resp = null;
		
		try {
			Course course = service.getOneCourse(id);
			LOG.info("COURSE OBJECT IS SELECTED {}",course);
			resp = ResponseEntity.ok(course);
		} catch (CourseNotFoundException e) {
			throw e; //re throw --> ExceptionHandler
		} catch (Exception e) {
			LOG.error("UNABLE TO FETCH COURSE {}", e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to FETCH Course",
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		LOG.info("RETURNING BACK FROM GET ONE COURSE METHOD ");
		return resp;
	}
	
	//3. Fetch All Courses
	@GetMapping
	public ResponseEntity<?> getAllCourses(
			@PageableDefault(page = 0,size = 3) Pageable pageable)
	{
		LOG.info("ENTERED INTO GET ALL COURSE METHOD");
		ResponseEntity<?> resp = null;
		try {
			Page<Course> page =  service.getAllCourses(pageable);
			resp = ResponseEntity.ok(page);
			LOG.info("COURSES OBJECT IS SELECTED {}",page);
		}  catch (Exception e) {
			LOG.error("UNABLE TO FETCH COURSES {}", e.getMessage());
			resp = new ResponseEntity<String>(
					"UNABLE TO FETCH COURSES",
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		LOG.info("RETURNING BACK FROM GET ALL COURSE METHOD ");
		return resp;
	}
	
	
	
}
