package in.nareshit.raghu.service;

import java.util.List;

import in.nareshit.raghu.model.Student;

public interface IStudentService {

	public Integer saveStudent(Student s);
	public List<Student> getAllStudents();
}
