package in.nareshit.raghu.consumer;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import in.nareshit.raghu.model.Course;

@FeignClient(name = "COURSE-SERVICE")
public interface CourseRestConsumer {

	@GetMapping("/course/{id}")
	public ResponseEntity<Course> getCourseById(
			@PathVariable Integer id);
	
}
