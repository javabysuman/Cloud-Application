package in.nareshit.raghu.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.consumer.CourseRestConsumer;
import in.nareshit.raghu.model.Course;
import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.service.IStudentService;

@RestController
@RequestMapping("/student")
public class StudentRestController {

	@Autowired
	private IStudentService service;
	
	@Autowired
	private CourseRestConsumer consumer;
	
	@PostMapping
	public ResponseEntity<String> saveStudent(
			@RequestBody Student student)
	{
		ResponseEntity<String> resp = null;
		try {
			//read Course ID from JSON Object and get Full Course Object
			Course cob = consumer.getCourseById(student.getCob().getCid()).getBody();
			//Link actual course object with Student object.
			student.setCob(cob);
			Integer id = service.saveStudent(student);
			resp = ResponseEntity.ok("Student '"+id+"' saved");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resp;
	}
	
}
